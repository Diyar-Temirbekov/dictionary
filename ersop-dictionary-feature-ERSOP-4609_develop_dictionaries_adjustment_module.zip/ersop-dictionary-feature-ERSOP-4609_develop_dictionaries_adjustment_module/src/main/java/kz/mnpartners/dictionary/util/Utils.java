package kz.mnpartners.dictionary.util;

import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class Utils {

    public static LocalDateTime getCurrentTime() {
        return LocalDateTime.now(ZoneId.of("Asia/Almaty"));
    }

    public static boolean isExcelFile(MultipartFile file) {
        if (file == null || file.isEmpty()) return false;
        String fileName = file.getOriginalFilename();
        return fileName != null && (fileName.toLowerCase().endsWith(".xls") || fileName.toLowerCase().endsWith(".xlsx"));
    }

    public static Optional<Long> parseLong(String value) {
        try {
            return Optional.ofNullable(value)
                    .filter(string -> !string.isBlank())
                    .map(Long::parseLong);
        } catch (NumberFormatException e) {
            return Optional.empty();
        }
    }

    public static List<String> getValidFields(Map<String, String> rowMap) {
        return rowMap.keySet().stream()
                .filter(field -> !"id".equals(field))
                .filter(field -> {
                    String value = rowMap.get(field);
                    return value != null && !value.isEmpty();
                })
                .toList();
    }
}