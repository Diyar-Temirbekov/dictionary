package kz.mnpartners.dictionary.util;

import kz.mnpartners.dictionary.exception.ExcelProcessingException;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@Component
public class ExcelParser {

    private final DataFormatter dataFormatter = new DataFormatter();

    public Map<String, List<Map<String, String>>> parseExcel(MultipartFile file) throws IOException {
        if (file == null || file.isEmpty()) {
            throw new ExcelProcessingException("Файл не может быть пустым");
        }

        Map<String, List<Map<String, String>>> sheetData = new LinkedHashMap<>();

        try (InputStream inputStream = file.getInputStream();
             Workbook workbook = new XSSFWorkbook(inputStream)) {

            IntStream.range(0, workbook.getNumberOfSheets())
                    .forEach(i -> {
                        Sheet sheet = workbook.getSheetAt(i);
                        sheetData.put(sheet.getSheetName(), parseSheet(sheet));
                    });
        }
        return sheetData;
    }

    private List<Map<String, String>> parseSheet(Sheet sheet) {
        if (sheet == null) {
            throw new ExcelProcessingException("Лист не может быть null");
        }

        Row headerRow = sheet.getRow(0);
        if (headerRow == null) {
            throw new ExcelProcessingException("Отсутствует строка заголовка в листе " + sheet.getSheetName());
        }

        List<String> columnNames = getColumnNames(headerRow);

        return IntStream.rangeClosed(1, sheet.getLastRowNum())
                .mapToObj(sheet::getRow)
                .filter(Objects::nonNull)
                .map(row -> createRowMap(row, columnNames))
                .collect(Collectors.toList());
    }

    private List<String> getColumnNames(Row headerRow) {
        return IntStream.range(0, headerRow.getLastCellNum())
                .mapToObj(headerRow::getCell)
                .filter(Objects::nonNull)
                .map(cell -> dataFormatter.formatCellValue(cell).trim())
                .filter(name -> !name.isEmpty())
                .collect(Collectors.toList());
    }

    private Map<String, String> createRowMap(Row row, List<String> columnNames) {
        Map<String, String> rowMap = new HashMap<>();

        IntStream.range(0, Math.min(columnNames.size(), row.getLastCellNum()))
                .forEach(colIndex -> {
                    Cell cell = row.getCell(colIndex, Row.MissingCellPolicy.RETURN_BLANK_AS_NULL);
                    String value = cell != null ? dataFormatter.formatCellValue(cell) : null;
                    rowMap.put(columnNames.get(colIndex), value != null && !value.isEmpty() ? value : null);
                });

        return rowMap;
    }
}