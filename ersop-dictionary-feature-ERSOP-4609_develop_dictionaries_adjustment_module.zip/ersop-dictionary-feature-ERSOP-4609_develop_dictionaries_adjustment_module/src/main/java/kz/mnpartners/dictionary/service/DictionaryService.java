package kz.mnpartners.dictionary.service;

import kz.mnpartners.dictionary.exception.ExcelProcessingException;
import kz.mnpartners.dictionary.repository.DictionaryRepository;
import kz.mnpartners.dictionary.util.ExcelParser;
import kz.mnpartners.dictionary.util.Utils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.BadSqlGrammarException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.sql.SQLException;
import java.util.*;

@Slf4j
@Service
@RequiredArgsConstructor
public class DictionaryService {

    private final DictionaryRepository dictionaryRepository;
    private final ExcelParser excelParser;

    @Transactional
    public void upsertExcelData(MultipartFile file) {
        String fileName = file.getOriginalFilename();
        log.info("Начата обработка файла: {}", fileName);

        if (!Utils.isExcelFile(file)) {
            log.warn("Не Excel: {}", fileName);
            throw new ExcelProcessingException("Поддерживаются только файлы формата .xls и .xlsx");
        }

        Map<String, List<Map<String, String>>> sheets;
        try {
            sheets = excelParser.parseExcel(file);
        } catch (IOException e) {
            log.error("Ошибка чтения {}: {}", fileName, e.getMessage(), e);
            throw new ExcelProcessingException("Ошибка чтения Excel", e);
        }

        try {
            for (var entry : sheets.entrySet()) {
                String table = entry.getKey();
                List<Map<String, String>> rows = entry.getValue();

                try {
                    if (!dictionaryRepository.tableExists(table)) {
                        throw new ExcelProcessingException(
                                String.format("Лист '%s' не соответствует ни одной таблице в БД. " +
                                        "Исправьте имя листа.", table)
                        );
                    }
                } catch (SQLException e) {
                    log.error("Ошибка проверки таблицы '{}': {}", table, e.getMessage(), e);
                    throw new ExcelProcessingException(
                            String.format("Не удалось проверить таблицу '%s': %s", table, e.getMessage()), e);
                }

                processTable(table, rows);
            }

            log.info("Файл '{}' успешно обработан", fileName);

        } catch (ExcelProcessingException e) {
            log.error("Ошибка обработки файла '{}': {}", fileName, e.getMessage(), e);
            throw e;
        } catch (Exception e) {
            log.error("Непредвиденная ошибка при обработке файла '{}': {}", fileName, e.getMessage(), e);
            throw new ExcelProcessingException("Ошибка при обработке Excel", e);
        }
    }

    private void processTable(String tableName, List<Map<String, String>> rows) {
        if (rows.isEmpty()) {
            throw new ExcelProcessingException(
                    String.format("Лист '%s' пустой — нечего загружать.", tableName));
        }

        List<String> pkCols = getPrimaryKeyColumns(tableName);
        if (pkCols.isEmpty()) {
            throw new ExcelProcessingException(
                    String.format("У таблицы '%s' не найден ни один PK‑столбец.", tableName));
        }

        convertKeysToLowercase(rows);
        validateTableColumnsExist(tableName, rows);
        mapExcelKeysToPrimaryKeys(rows, pkCols);
        upsertRows(tableName, rows, pkCols);
    }

    private void convertKeysToLowercase(List<Map<String, String>> rows) {
        for (int i = 0; i < rows.size(); i++) {
            Map<String, String> original = rows.get(i);
            Map<String, String> lower = new LinkedHashMap<>();
            for (var entry : original.entrySet()) {
                lower.put(entry.getKey().toLowerCase(), entry.getValue());
            }
            rows.set(i, lower);
        }
    }

    private void validateTableColumnsExist(String tableName, List<Map<String, String>> rows) {
        List<String> dbCols;
        try {
            dbCols = dictionaryRepository.getTableColumns(tableName);
        } catch (SQLException e) {
            throw new ExcelProcessingException(
                    String.format("Не удалось получить список столбцов для '%s': %s", tableName, e.getMessage()), e);
        }

        List<String> relevantCols;
        if (tableName.startsWith("f_")) {
            try {
                relevantCols = dictionaryRepository.getPrimaryKeyColumns(tableName);
            } catch (SQLException e) {
                throw new ExcelProcessingException(
                        String.format("Не удалось получить список первичных ключей для '%s': %s",
                                tableName, e.getMessage()), e);
            }
        } else {
            relevantCols = dbCols;
        }

        for (int i = 0; i < rows.size(); i++) {
            Map<String, String> row = rows.get(i);

            for (String col : row.keySet()) {
                if (tableName.startsWith("f_")) {
                    if (!relevantCols.contains(col) && new HashSet<>(relevantCols).containsAll(row.keySet())) {
                        throw new ExcelProcessingException(
                                String.format("Для таблицы '%s' разрешены только столбцы первичного ключа %s (строка %d). Лишние столбцы: %s",
                                        tableName, relevantCols, i + 1, col));
                    }
                } else {
                    if (!relevantCols.contains(col)) {
                        throw new ExcelProcessingException(
                                String.format("Таблица '%s' не содержит столбца '%s' (строка %d). Исправьте имя.",
                                        tableName, col, i + 1));
                    }
                }
            }
        }
    }

    private List<String> getPrimaryKeyColumns(String tableName) {
        try {
            return dictionaryRepository.getPrimaryKeyColumns(tableName);
        } catch (SQLException e) {
            throw new ExcelProcessingException("Не удалось получить PK для " + tableName, e);
        }
    }

    private void mapExcelKeysToPrimaryKeys(List<Map<String, String>> rows, List<String> pkCols) {
        for (var row : rows) {
            for (int i = 0; i < pkCols.size(); i++) {
                String excelKey = (i == 0 ? "id" : "id" + (i + 1));
                String pk = pkCols.get(i);
                if (!row.containsKey(pk) && row.containsKey(excelKey)) {
                    row.put(pk, row.get(excelKey));
                }
            }
        }
    }

    private void upsertRows(String tableName,
                            List<Map<String, String>> rows,
                            List<String> pkCols) {

        for (int rowIndex = 0; rowIndex < rows.size(); rowIndex++) {
            Map<String, String> row = rows.get(rowIndex);

            boolean exists;
            try {
                Map<String, Object> keyMap = new HashMap<>();
                for (String pk : pkCols) {
                    String raw = row.get(pk);
                    keyMap.put(pk, Utils.parseLong(raw).<Object>map(x -> x).orElse(raw));
                }
                exists = dictionaryRepository.existsByKey(tableName, pkCols, keyMap);

            } catch (BadSqlGrammarException bsge) {
                throw new ExcelProcessingException(
                        String.format("Неверный тип значения в PK‑столбце таблицы '%s' (строка %d)",
                                tableName, rowIndex + 1), bsge);
            } catch (DataAccessException dae) {
                dae.getMostSpecificCause();
                String msg = dae.getMostSpecificCause().getMessage();
                throw new ExcelProcessingException(
                        String.format("Ошибка проверки существования записи в таблице '%s' (строка %d): %s",
                                tableName, rowIndex + 1, msg), dae);
            }

            try {
                List<String> allFields = determineFieldsForTable(tableName, List.of(row), pkCols);
                if (exists) {
                    dictionaryRepository.updateRecord(tableName, allFields, pkCols, row);
                } else {
                    dictionaryRepository.insertRecord(tableName, allFields, row);
                }

            } catch (DataAccessException dae) {
                dae.getMostSpecificCause();
                String msg = dae.getMostSpecificCause().getMessage();

                if (msg.toLowerCase().contains("duplicate key")) {
                    throw new ExcelProcessingException(
                            String.format("Ошибка вставки в таблицу '%s', строка %d: " +
                                            "запись с таким ключом уже существует.", tableName, rowIndex + 1), dae);
                }

                throw new ExcelProcessingException(
                        String.format("Ошибка при записи в таблицу '%s', строка %d:", tableName, rowIndex + 1), dae);
            }
        }
    }

    private List<String> determineFieldsForTable(String tableName, List<Map<String, String>> rows,
                                                 List<String> pkCols) {
        List<String> fields;
        if (tableName.startsWith("f_")) {
            fields = new ArrayList<>(pkCols);
            fields.add("date_entry");
        } else {
            fields = new ArrayList<>(Utils.getValidFields(rows.getFirst()));
            for (String pk : pkCols) {
                if (!fields.contains(pk)) {
                    fields.add(pk);
                }
            }
        }
        return fields;
    }
}