package kz.mnpartners.dictionary.repository;

import kz.mnpartners.dictionary.util.Utils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Repository
@RequiredArgsConstructor
public class DictionaryRepository {

    private final NamedParameterJdbcTemplate jdbcTemplate;
    private final DataSource dataSource;

    public List<String> getPrimaryKeyColumns(String tableName) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             ResultSet resultSet = conn.getMetaData().getPrimaryKeys(null, null, tableName)) {
            List<String> primaryKeys = new ArrayList<>();
            while (resultSet.next()) {
                primaryKeys.add(resultSet.getString("COLUMN_NAME"));
            }
            return primaryKeys;
        }
    }

    public List<String> getTableColumns(String tableName) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             ResultSet rs = conn.getMetaData().getColumns(null, null, tableName, null)) {
            List<String> columns = new ArrayList<>();
            while (rs.next()) {
                columns.add(rs.getString("COLUMN_NAME").toLowerCase());
            }
            return columns;
        }
    }

    public boolean tableExists(String tableName) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             ResultSet rs = conn.getMetaData().getTables(null, null, tableName, new String[]{"TABLE"})) {
            return rs.next();
        }
    }

    public boolean existsByKey(String tableName, List<String> pkCols, Map<String, Object> keyValues) {
        String where = pkCols.stream()
                .map(col -> col + " = :" + col)
                .collect(Collectors.joining(" AND "));
        String sql = String.format("SELECT 1 FROM %s WHERE %s LIMIT 1", tableName, where);
        return !jdbcTemplate.queryForList(sql, keyValues).isEmpty();
    }

    public void insertRecord(String tableName, List<String> allFields, Map<String, String> rowMap) {
        String columns = String.join(", ", allFields);
        String values = allFields.stream().map(field -> ":" + field).collect(Collectors.joining(", "));
        String sql = String.format("INSERT INTO %s (%s) VALUES (%s)", tableName, columns, values);

        jdbcTemplate.update(sql, createParameterSource(rowMap, Utils.getCurrentTime()));
    }

    public void updateRecord(String tableName, List<String> allFields, List<String> pkCols, Map<String, String> rowMap) {
        String setClause = allFields.stream()
                .filter(field -> !pkCols.contains(field))
                .map(field -> field + " = :" + field)
                .collect(Collectors.joining(", "));
        String where = pkCols.stream()
                .map(pk -> pk + " = :" + pk)
                .collect(Collectors.joining(" AND "));
        String sql = String.format("UPDATE %s SET %s WHERE %s", tableName, setClause, where);

        jdbcTemplate.update(sql, createParameterSource(rowMap, Utils.getCurrentTime()));
    }

    private SqlParameterSource createParameterSource(Map<String, String> rowMap, LocalDateTime currentTime) {
        MapSqlParameterSource params = new MapSqlParameterSource();

        rowMap.forEach((key, value) -> {
            if (value == null || value.isBlank()) {
                params.addValue(key, null);
            } else if ("true".equalsIgnoreCase(value) || "false".equalsIgnoreCase(value)
                    || "null".equalsIgnoreCase(value) || "default".equalsIgnoreCase(value)) {
                params.addValue(key, Boolean.parseBoolean(value));
            } else if (value.matches("\\d+")) {
                params.addValue(key, Long.parseLong(value));
            } else {
                params.addValue(key, value);
            }
        });

        if (rowMap.containsKey("date_entry")) {
            params.addValue("date_entry", currentTime);
        } else {
            params.addValue("date_entry", currentTime.plusHours(5));
        }

        return params;
    }
}