package kz.mnpartners.dictionary;

import org.springframework.boot.Banner;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;

@SpringBootApplication
public class ErsopDictionaryApplication {

    public static void main(String[] args) {
        new SpringApplicationBuilder(ErsopDictionaryApplication.class).bannerMode(Banner.Mode.OFF).run(args);
    }
}